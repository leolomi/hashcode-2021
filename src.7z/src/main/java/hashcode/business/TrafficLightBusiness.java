package hashcode.business;

import java.util.Map;

import hashcode.model.InputFile;
import hashcode.model.Intersection;
import hashcode.model.OutputFile;
import hashcode.model.Street;

public class TrafficLightBusiness {

	public static OutputFile setTrafficLightTime(InputFile inputFile) {

		final OutputFile out = new OutputFile();

		for (final Map.Entry<Integer, Intersection> entry : inputFile.getIntersectionMap().entrySet()) {
			for(final Street street : entry.getValue().getIncommingStreets()) {
				street.setTimeOnTrafficLight(street.getNbOfCars());
			}
		}

		out.setIntersectionMap(inputFile.getIntersectionMap());

		return out;
	}

}
